# Deep-Wallpaper

Mobile Wallpaper Imaging URL
https://www.setaswall.com/1080x1920-wallpapers/
https://wallpaperaccess.com/search?q=Mobile
https://www.pexels.com/search/mobile%20wallpaper/
https://statusqueen.com/hd-mobile-wallpaper
https://graffitiwallpaper.com/

Computer and Laptop Imaging URL
https://unsplash.com/wallpapers/desktop
https://www.pexels.com/search/desktop%20wallpaper/
https://pixabay.com/images/search/desktop%20wallpaper/
https://wallpaperaccess.com/pc
https://www.shutterstock.com/search/desktop+wallpaper
